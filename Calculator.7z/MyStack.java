/**
 * 双向链表
 * 双向链表实现栈操作
 * @param <E>
 */
class DoubleLinkedList<E> {
    public E data;       //链表中存储的数据
    public DoubleLinkedList<E> prev;   //指向上一个节点
    public DoubleLinkedList<E> next;   //指向下一个节点

    //含参构造器,用于初始化data
    public DoubleLinkedList(E data) {
        this.data = data;
    }

    //空参构造器,data初始化为null
    public DoubleLinkedList() {
        this.data = null;
    }
}

/**
 * 栈
 * @param <E>
 */
public class MyStack<E> {
    private DoubleLinkedList<E> head;   //定义头指针,实际不存放有效数据
    private DoubleLinkedList<E> tail;   //定义尾指针,实际不存放有效数据

    /**
     * 空参构造器
     * 初始化头指针和尾指针,建立只含有 head 和 tail 的双向链表
     */
    public MyStack() {
        head = new DoubleLinkedList<>();
        tail = new DoubleLinkedList<>();
        head.prev = null;
        head.next = tail;
        tail.prev = head;
        tail.next = null;
    }

    /**
     * 入栈操作
     * 只需要在链表尾部插入数据,即 tail.prev 指向一个要插入的数据
     * @param elem 入栈数据
     */
    public void push(E elem) {
        DoubleLinkedList<E> temp = tail.prev;
        DoubleLinkedList<E> node = new DoubleLinkedList<>(elem);
        //建立新的双向链表
        temp.next = node;
        node.prev = temp;
        node.next = tail;
        tail.prev = node;
    }

    /**
     * 返回栈顶数据, 即链表尾节点的上一个节点的数据
     * @return 栈顶数据
     */
    public E peek() {
        return tail.prev.data;
    }

    /**
     * 出栈操作
     * 将链表中尾节点删除,即 tail.prev 节点删除
     * @return 栈顶数据
     */
    public E pop(){
        //先判断链表是否为空
        if (isEmpty()) {
            return null;
        }
        DoubleLinkedList<E> temp = tail.prev.prev;
        E data = tail.prev.data;    //保存返回值
        temp.next = tail;           //删除尾节点,即tail.prev
        tail.prev = temp;           //删除尾节点
        return data;
    }

    /**
     * 判断栈是否为空,即链表是否为空
     * 若链表为空,tail.prev = head; tail.prev.prev = head.prev = null
     * @return 若栈空返回true, 否则返回false
     */
    public boolean isEmpty() {
        if (tail.prev.prev == null)
            return true;
        return false;
    }

    /**
     * 反转栈,将栈的数据反转,即反转链表
     * 实质是反转相邻两个节点之间的指向关系
     */
    public void reverse() {
        DoubleLinkedList<E> tempHead = head;    //保存头部,反转之后头部改变为尾部
        DoubleLinkedList<E> temp1 = head;       //相邻节点的前一个
        DoubleLinkedList<E> temp2 = temp1.next; //相邻节点的后一个
        temp1.next = null;                      //定义尾部节点的后一个节点为空
        while (temp2 != null) {
            //交换相邻节点之间的指向关系
            DoubleLinkedList<E> tempNext = temp2.next;
            temp1.prev = temp2;
            temp2.next = temp1;
            temp1 = temp2;
            temp2 = tempNext;
        }
        temp1.prev = null;      //定义头部的前一个节点为空
        head = temp1;           //头部变为原来的尾部
        tail = tempHead;        //尾部变为原来的头部
    }

    /**
     * 栈中元素个数
     * @return 栈中元素个数
     */
    public int size() {
        int length = 0;
        DoubleLinkedList<E> temp = head.next;
        while (temp != tail) {
            length++;
            temp = temp.next;
        }
        return length;
    }
}
