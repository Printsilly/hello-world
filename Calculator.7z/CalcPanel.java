import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.Arrays;

public class CalcPanel extends JPanel {
    private JPanel displayPanel;     //该面板用于显示用户输入的表达式和计算结果
    private JPanel buttonPanel;       //该面板用于显示按键
    private JButton[] buttons;          //按键数组
    private JLabel expression;        //显示输入表达式的标签
    private JLabel HEX;                //16进制显示标签
    private JLabel DEC;                 //10进制显示标签
    private JLabel BIN;                 //2进制显示标签
    private JLabel RPE;                 //后缀表达式标签
    //按钮的显示字符
    private final String tags[] = {"ln ","!","CE","DEL","sin","cos","tan","∧","(",")","%","÷","7","8","9","×","4","5","6","-","1","2","3","+",".","0",".","="};
    //用于计算表达式结果的类（不用转后缀表达式）
    private Calculator calculator;
    //转后缀表达式的类
    private CalculatorRPE rpe;

    //构造函数 GUI布局
    public CalcPanel() {
        rpe = new CalculatorRPE();

        //设置为绝对布局
        setLayout(null);
        expression = new JLabel(" 0");
        expression.setHorizontalAlignment(SwingConstants.RIGHT);
        expression.setFont(new Font("宋体",Font.BOLD,40));
        expression.setBounds(0,0,500,100);

        HEX = new JLabel(" HEX 0");
        HEX.setFont(new Font("宋体",Font.PLAIN,20));
        HEX.setBounds(0,130,500,40);

        DEC = new JLabel(" DEC 0");
        DEC.setFont(new Font("宋体",Font.PLAIN,20));
        DEC.setBounds(0,180,500,40);

        BIN = new JLabel(" BIN 0");
        BIN.setFont(new Font("宋体",Font.PLAIN,20));
        BIN.setBounds(0,230,500,40);

        RPE = new JLabel(" RPE -");
        RPE.setFont(new Font("宋体",Font.PLAIN,20));
        RPE.setBounds(0,280,500,40);

        displayPanel = new JPanel(null);
        displayPanel.setOpaque(true);
        displayPanel.setBounds(0,0,500,340);
        displayPanel.setBackground(new Color(240,240,240));
        displayPanel.add(expression);
        displayPanel.add(HEX);
        displayPanel.add(DEC);
        displayPanel.add(BIN);
        displayPanel.add(RPE);

        buttonPanel = new JPanel(new GridLayout(7,4,1,1));
        buttonPanel.setBounds(0,350,500,335);
        buttonPanel.setBackground(new Color(240,240,240));


        //添加按钮
        buttons = new JButton[28];
        for (int i = 0; i < 28; i++) {
            buttons[i] = new JButton(tags[i]);
            if (i != 2 && i!=3)
                buttons[i].setForeground(Color.gray);
            //设置计算器按键的背景颜色
            if (i<12 || i%4 == 3){
                buttons[i].setBackground(new Color(235,235,235));
            } else
                buttons[i].setBackground(new Color(250,250,250));
            buttonPanel.add(buttons[i]);
            buttons[i].setFont(new Font("宋体",Font.BOLD,20));

            //消除按键点击后产生的虚线框
            buttons[i].setFocusPainted(false);
            //鼠标移动到按键上 让该按键的颜色发生变化
            //用户体验更友好
            buttons[i].addMouseListener(new MouseAdapter() {
                Color background;
                @Override
                public void mouseEntered(MouseEvent e) {
                    background = ((JButton) e.getSource()).getBackground();
                    ((JButton)e.getSource()).setBackground(new Color(205,205,205));
                }
                @Override
                public void mouseExited(MouseEvent e) {
                    ((JButton)e.getSource()).setBackground(background);
                }
            });
            if (i!=2&&i!=3&&i!=27){
                buttons[i].addActionListener(new ActionListener() {
                    public void actionPerformed(ActionEvent e) {
                        String text = ((JButton) e.getSource()).getText();
                        if (expression.getText().equals(" 0")||expression.getText().equals("Error"))
                            expression.setText(text);
                        else
                            expression.setText(expression.getText()+text);
                        transfer();
                        expression.requestFocus();
                    }
                });
            }
        }
        buttons[27].setBackground(new Color(145,205,209));
        buttons[27].addMouseListener(new MouseAdapter() {
            Color background;
            @Override
            public void mouseEntered(MouseEvent e) {
                background = ((JButton) e.getSource()).getBackground();
                ((JButton)e.getSource()).setBackground(new Color(73,178,185));
            }
        });

        //给等号添加触发事件
        buttons[27].addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                calculator = new Calculator();
                String expressionText = expression.getText();

                try {
                    RPE.setText(" RPE "+rpe.token(expressionText));
                }catch (Exception e1){
                    System.out.println("逆波兰不支持非法字符");
                }
                try {
                    expressionText += "=";
                    double value = calculator.valueOfExp(expressionText);
                    expression.setText(String.valueOf(value));
                }catch (Exception exception){
                    expression.setText("Error");
                }

            }
        });

        //归0按钮监听
        buttons[2].addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                expression.setText(" 0");
                DEC.setText(" DEC 0");
                HEX.setText(" HEX 0");
                BIN.setText(" BIN 0");
            }
        });

        //删除按钮监听
        buttons[3].addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String exp = expression.getText();
                if (exp.equals(" 0")||exp.length()==1){
                    expression.setText(" 0");
                }else {
                    expression.setText(exp.substring(0,exp.length()-1));
                }
                transfer();
            }
        });


        add(displayPanel);
        add(buttonPanel);

        //键盘监听  可以从键盘输入
        expression.setFocusable(true);
        expression.requestFocus();
        expression.addKeyListener(new KeyAdapter() {
            @Override
            public void keyTyped(KeyEvent e) {
                char keyChar = e.getKeyChar();
                //若敲击回退
                if (keyChar == KeyEvent.VK_BACK_SPACE){
                    buttons[3].doClick();
                }if (keyChar == KeyEvent.VK_ENTER){
                    buttons[27].doClick();
                } else{
                    //判断键盘输入的字符是否为合法字符
                    boolean contains = Arrays.asList(tags).contains(Character.toString(keyChar));
                    if (contains){
                        int index = Arrays.asList(tags).indexOf(Character.toString(keyChar));
                        buttons[index].doClick();
                    }
                }
            }
        });
    }

    //转换为对应进制显示在界面上
    private void transfer(){
        try {
            DEC.setText(" DEC "+expression.getText());
            HEX.setText(" HEX "+Integer.toHexString(Integer.parseInt(expression.getText())));
            BIN.setText(" BIN "+Integer.toBinaryString(Integer.parseInt(expression.getText())));
        }catch (Exception exception){
            DEC.setText(" DEC 0");
            HEX.setText(" HEX 0");
            BIN.setText(" BIN 0");
        }
    }
}