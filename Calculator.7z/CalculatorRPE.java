public class CalculatorRPE {
    public MyStack<String> opStack;
    public MyStack<String> RPEStack;
    public MyStack<Double> digitStack;
    public CalculatorRPE(){
        opStack = new MyStack<>();
        RPEStack = new MyStack<>();
        digitStack = new MyStack<>();
    }

    //将字符串分成一个个块 去调用后缀转化函数 为了区分32.1 这种小数
    public String token(String str){
        //初始化 temp 为空字符串
        String temp = "";
        //依次读取str中每个字符
        for(int i=0;i<str.length();i++){
            // p 是当前字符
            char p = str.charAt(i);
            //如果是数字 或. 将其连结到temp后面
            if(Character.isDigit(p) || p == '.')
                temp += p;
                //如果是其他符号 先判断temp有没有 有则将temp转化
                //再将当前字符（非数字）转化
            else {
                if(temp.length()>0){
                    parseToSuffixExpression(temp);
                    temp = "";//再次将temp变成空字符
                }
                parseToSuffixExpression(String.valueOf(p));
            }

        }
        //最后一个块是数字的时候 对最后一个数字进行转化
        //比如 1+2 上一个循环结束时 2还存在temp中未转化
        if(temp.length()>0)
            parseToSuffixExpression(temp);
        //循环完毕，如果操作符栈中元素不为空，将栈中元素出栈压入RPEStack
        while (!opStack.isEmpty()) {
            RPEStack.push(opStack.pop());
        }
        //先把RPEStack反转 此时才是正确顺序
        RPEStack.reverse();

        //RPEString 用于存放逆波兰式的字符串
        String RPEString = "";
        while(!RPEStack.isEmpty()){
            RPEString += RPEStack.pop();
        }
        return RPEString;  //返回转换后的逆波兰式字符串
    }

    public void  parseToSuffixExpression(String str) {
        if (isOperator(str)) {
            //是操作符 判断操作符栈是否为空
            if (opStack.isEmpty() || "(".equals(opStack.peek()) || priority(str) >= priority(opStack.peek())) {
                //为空或者栈顶元素为左括号或者当前操作符大于栈顶操作符直接压栈
                opStack.push(str);
            } else {
                //否则将栈中元素出栈入RPEStack，直到遇到大于当前操作符或者遇到左括号时
                while (!opStack.isEmpty() && !"(".equals(opStack.peek())) {
                    if (priority(str) <= priority(opStack.peek())) {
                        RPEStack.push(opStack.pop());
                    }
                }
                //当前操作符压栈
                opStack.push(str);
            }
        } else if (isNumber(str)) {
            //是数字则直接入RPEStack
            RPEStack.push(str);
        } else if ("(".equals(str)) {
            //是左括号，压栈
            opStack.push(str);
        } else if (")".equals(str)) {
            //是右括号 ，将栈中元素弹出入队，直到遇到左括号，左括号出栈，但不入RPEStack
            while (!opStack.isEmpty()) {
                if ("(".equals(opStack.peek())) {
                    opStack.pop();
                    break;
                } else {
                    RPEStack.push(opStack.pop());
                }
            }
        } else {
            throw new RuntimeException("有非法字符！");
        }
    }

    public int priority(String op){
        if(op.equals("∧") || op.equals("!"))
            return 2;
        else if(op.equals("×") || op.equals("÷")){
            return 1;
        }else if(op.equals("+") || op.equals("-")){
            return 0;
        }
        return -1;
    }

    private boolean isOperator(String c){
        return c.equals("+") ||c.equals("-")||c.equals("×")||c.equals("÷") ||c.equals("∧");
    }

    public static boolean isNumber(String str){
        String reg = "^[0-9]+(.[0-9]+)?$";
        return str.matches(reg);
    }

    public double calculate(){
        //RPEStack.reverse();
        while (!RPEStack.isEmpty()){
            String container = RPEStack.pop();
            if (isOperator(container)){
                if(container.equals("+")){
                    digitStack.push(digitStack.pop() + digitStack.pop());
                }
                else if(container.equals("×")){
                    digitStack.push(digitStack.pop() * digitStack.pop());
                }
                else if(container.equals("-")){
                    double b = digitStack.pop();
                    double a = digitStack.pop();
                    digitStack.push(a-b);
                }
                else if(container.equals("÷")){
                    double b = digitStack.pop();
                    double a = digitStack.pop();
                    digitStack.push(a/b);
                }
                else if(container.equals("∧")){
                    double b = digitStack.pop();
                    double a = digitStack.pop();
                    digitStack.push(Math.pow(a,b));
                }
            }else {
                double num = Double.parseDouble(container);
                digitStack.push(num);
            }
        }
        return digitStack.pop();
    }

}

