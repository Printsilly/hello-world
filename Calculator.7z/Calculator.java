public class Calculator {
    private MyStack<Double> operand;
    private MyStack<Character> operator;

    //构造函数  初始化两个栈
    public Calculator() {
        operand = new MyStack<>();    //操作数栈
        operator = new MyStack<>();    //操作符和界限符栈
    }

    /**
     * 判断一个字符是不是规定的操作符
     * @param c 被判断的字符
     * @return 是则返回true 否则为false
     */
    private boolean isOperator(char c) {
        return c == '+' || c == '-' || c == '×' || c == '÷' || c == '%'|| c == '∧' || c == 's'|| c == 'c'|| c == 't'|| c == 'l'|| c == '!';
    }

    /**
     *
     * @param exp  表达式字符串
     * @return  根据中缀表达式计算出的结果
     */
    public double valueOfExp(String exp) throws Exception{
        String temp = "";   //用于存放一个操作数
        for (int i = 0; i < exp.length(); i++) {
            char p = exp.charAt(i); //p用来保存当前字符

            //如果是数字或. 将其连结到temp后面
            if (Character.isDigit(p) || p == '.') {
                temp += p;
                continue;
            }

            //如果遇到左括号  压入栈
            if (p == '(') {
                if (!temp.equals("")){
                    operand.push(Double.valueOf(temp));
                    temp = "";
                }
                operator.push(p);
                continue;
            }

            //表示输入负号的情况
            if (p == '-' && temp.equals("") && exp.charAt(i-1)!=')'){
                operand.push(0.0);
            }

            //操作符处理
            if (isOperator(p)) {
                //如果扫描到sin cos tan  则跳过后两个字符 只读取第一个字符
                if (p == 's' ||p == 'c' ||p == 't' ||p == 'l' )
                    i+=2;
                //表示一个数字已经结束
                //压入数字后重置temp为空
                if (!temp.equals("")){
                    operand.push(Double.valueOf(temp));
                    temp = "";
                }
                if (!operator.isEmpty()){
                    char top = operator.peek();  //查看处于栈顶的一个运算符

                    //如果栈顶的运算符优先级大于等于当前读取到的运算符的优先级
                    //就弹出进行运算
                    while (priorityGate(p, top)) {
                        calculate();
                        if (operator.isEmpty())
                            break;
                        else
                            top = operator.peek();
                    }
                }
                //最后再压入当前读到的操作符
                operator.push(p);
            }

            //遇到右括号就一直弹出操作符栈中的元素直至遇到左括号
            //再弹出操作符的过程中进行运算后结果再压入操作数栈
            if (p == ')'){
                if (!temp.equals("")){
                    operand.push(Double.valueOf(temp));
                    temp = "";
                }
                char top = operator.peek();  //处于栈顶的一个运算符
                while (top != '(') {
                    calculate();
                    top = operator.peek();
                }

                //将左括号弹出栈
                operator.pop();
            }

            //如果遇到等号，且等号前还有数字则作将数字压入栈
            if (p == '='){
                if (!temp.equals("")){
                    operand.push(Double.valueOf(temp));
                    temp = "";
                }
                while (operand.size()>1 || !operator.isEmpty())
                    calculate();
            }
        }
        //返回操作数中的最后一个元素，就是结果
        return operand.pop();
    }

    /**
     * 比较两个运算符的优先级  优先级按下方依次递增
     * @param a
     * @param b
     * @return  b  >=  a  返回true
     */
    private boolean priorityGate(char a, char b) {
        boolean flag = false;
        switch (a) {
            case '+':
            case '-':
                if (b == '+' || b == '-' || b == '×' || b == '÷'|| b == '%'||b == 's' || b == 'c' || b == 't' || b == 'l'||b == '∧'||b == '!')
                    flag = true;
                break;
            case '×':
            case '%':
            case '÷':
                if (b == '×' || b == '÷'||b == 's' || b == '%'|| b == 'c' || b == 't' || b == 'l'||b == '∧'||b == '!')
                    flag = true;
                break;
            case 's':
            case 'c':
            case 't':
            case 'l':
            case '!':
                if (b == 's' || b == 'c' || b == 't' || b == 'l'||b == '∧'||b == '!')
                    flag = true;
                break;
            case '∧':
                if (b == '∧'||b == '!')
                    flag = true;
                break;
        }
        return flag;
    }

    /**
     * 弹出一个操作符，弹出两个操作数（如果是阶乘、sin这种就只弹出一个操作数计算）
     * 运算完后再压入栈
     */
    private void calculate() throws Exception{
        if(operator.isEmpty())
            throw new Exception();
        char op = operator.pop();
        double opr1 = operand.pop();
        double opr2 = 0;
        if (op == '+' || op == '-' || op == '×' || op == '÷' || op == '∧'|| op == '%')
            opr2 = operand.pop();
        switch (op) {
            case '+':
                operand.push(opr2 + opr1);
                break;
            case '-':
                operand.push(opr2 - opr1);
                break;
            case '×':
                operand.push(opr2 * opr1);
                break;
            case '÷':
                operand.push(opr2 / opr1);
                break;
            case '%':
                operand.push(opr2 % opr1);
                break;
            case 's':
                operand.push(Math.sin(opr1));
                break;
            case 'c':
                operand.push(Math.cos(opr1));
                break;
            case 't':
                operand.push(Math.tan(opr1));
                break;
            case 'l':
                operand.push(Math.log(opr1));
                break;
            case '∧':
                operand.push(Math.pow(opr2,opr1));
                break;
            case '!':
                operand.push(factorial(opr1));
                break;
        }
    }

    /**
     * 计算乘方主体函数
     * @param n 需要计算阶乘的数字
     * @return result  数字的阶乘
     * @throws Exception    小数部分不能舍弃时抛出异常,GUI部分负责接收异常
     */
    private double factorial(double n) throws Exception {
        double result;     //计算结果
        try {
            result = 1;
            String str = isInteger(n);      //返回小数的整数部分,不能转整数则抛出异常
            int parse = Integer.parseInt(String.valueOf(str));  //负责将str字符串转成整数
            //循环计算阶乘
            for (int i = 1; i <= parse; i++) {
                result = result * i;
            }
        }
        catch (Exception e) {
            throw new Exception();  //抛出异常
        }
        return result;
    }

    /**
     * 判断是不是整数
     * @param n 浮点数n
     * @return  数字的整数部分(小数部分可以舍弃时)
     * @throws Exception 小数部分不能舍弃时抛出异常,GUI部分负责接收异常
     */
    private String isInteger(double n) throws Exception {
        if (n < 0) {    //数字小于0时直接抛出异常
            throw new Exception();
        }
        String str = String.valueOf(n);     //小数转成字符串
        int index = 0;
        //从左往右扫描字符串直到遇到小数点
        while (index < str.length()) {
            if (str.charAt(index) == '.') {
                break;
            }
            index++;
        }
        index++;
        //扫描小数点后是否全是0
        //不全为0时抛出异常,GUI负责接收异常
        while (index < str.length()) {
            if (str.charAt(index) != '0') {
                throw new Exception();
            }
            index++;
        }
        //返回n的整数部分(当能转成整数时)
        return str.substring(0, index-2);
    }
}
