import javax.swing.*;

public class Start {
    public static void main(String[] args) {
        JFrame frame = new JFrame("G02计算器");
        //运行图标设置
        ImageIcon icon = new ImageIcon("ICON.jpg");
        frame.setIconImage(icon.getImage());
        frame.setBounds(0,0,514,720);
        frame.add(new CalcPanel());
        frame.setResizable(false);
        frame.setVisible(true);
        frame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        frame.setLocationRelativeTo(null);
    }
}
