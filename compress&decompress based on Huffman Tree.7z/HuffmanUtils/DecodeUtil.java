package HuffmanUtils;

import HuffmanTree.HuffNode;
import HuffmanTree.HuffTree;

import java.io.*;

public class DecodeUtil {
    private File source,config;           //待压缩的文件
    private Long size;       //文件的大小
    private Long down = 0L;     //已完成的字节数
    private String dest;
    private FileMsg fileMsg;     //保存文件的信息
    private HuffTree huffTree;

    public DecodeUtil(String source, String dest) {
        this.source = new File(source);
        size = this.source.length();

        String[] split = this.source.getName().split("\\.");
        config = new File("C:\\AppData\\"+split[0]+".cfg");
        //先读取文件的头部信息
        try(ObjectInputStream objIn = new ObjectInputStream(new FileInputStream(config));) {
            fileMsg = (FileMsg) objIn.readObject();
        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
        }

    }

    public void decode(){
        try(BufferedInputStream in = new BufferedInputStream(new FileInputStream(source));
            BufferedOutputStream out = new BufferedOutputStream(new FileOutputStream(dest,true))){

            //创建目的文件
            File destFile = new File(dest);
            if (!destFile.exists()) {
                destFile.createNewFile();
            }

            huffTree = new HuffTree(fileMsg.weight);
            HuffNode node = huffTree.getRoot();

            byte[] bytes = new byte[1024];
            int len;
            int i;
            boolean flag = false;
            while((len = in.read(bytes))!= -1){
                for (i = 0; i<len;i++){
                    if (down==size-1&&fileMsg.lastByteLength>0){
                        flag = true;
                        break;
                    }

                    for (int j = 0;j<8;j++) {
                        boolean bit = getBit(bytes[i], j);

                        if (bit) {
                            node = node.getRight();
                        } else {
                            node = node.getLeft();
                        }
                        if (node.isLeaf()) {
                            out.write((byte) (node.getValue() - 128));
                            node = huffTree.getRoot();
                        }
                    }
                    down++;
                }
                if (flag)
                    break;
            }

            if (fileMsg.lastByteLength>0){
                byte b = bytes[len-1];
                for(int j = 0;j < fileMsg.lastByteLength;j++){
                    boolean bit = getBit(b, j);
                    if (bit){
                        node = node.getRight();
                    }else {
                        node = node.getLeft();
                    }
                    if (node.isLeaf()){
                        out.write((byte)(node.getValue()-128));
                        node = huffTree.getRoot();
                    }
                }
                down++;
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private boolean getBit(byte b,int index){
        return ((1<<(index^7))&b)!=0;
    }

    public FileMsg getFileMsg() {
        return fileMsg;
    }

    public void setDest(String dest) {
        this.dest = dest;
    }

    public int getSchedule(){
        return (int) ((down.doubleValue()/size)*100);
    }
}
