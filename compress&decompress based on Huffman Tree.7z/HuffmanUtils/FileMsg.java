package HuffmanUtils;

import java.io.Serializable;

public class FileMsg implements Serializable {
    private static final long serialVersionUID = -6743567631108323096L;
    public int[] weight;        //保存每个字符的权重
    public byte lastByteLength;          //最后一个字节
    public String fileFormat;       //文件的格式

    public FileMsg(int[] weight, byte lastByteLength, String fileFormat) {
        this.weight = weight;
        this.lastByteLength = lastByteLength;
        this.fileFormat = fileFormat;
    }
}
