package HuffmanUtils;

import HuffmanTree.HuffNode;
import HuffmanTree.HuffTree;

import java.io.*;
import java.util.HashMap;

public class EncodeUtil {
    private File source,dest,config;           //待压缩的文件 , 目的地址文件  配置文件
    private FileMsg fileMsg;     //保存文件的信息
    private HuffTree huffTree;
    private Long size;       //文件的大小
    private Long down = 0L;     //已完成的字节数

    public EncodeUtil(String source,String dest) {
        this.source = new File(source);
        size = this.source.length();

        String fileType = getFileExtension(this.source);
        this.fileMsg = new FileMsg(getArray(), (byte) 0,fileType);

        this.dest = new File(dest);
        if (!this.dest.exists()) {
            try {
                this.dest.createNewFile();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        String[] split = this.dest.getName().split("\\.");
        config = new File("C:\\AppData\\"+split[0]+".cfg");

        huffTree = new HuffTree(getArray());
    }

    /**
     * 读取文件，得到每个字符权重
     */
    private int[] getArray(){
        int[] weight = new int[256];
        try(BufferedInputStream in  = new BufferedInputStream(new FileInputStream(source))){
            byte[] bytes = new byte[1024];
            int len;
            while ((len =in.read(bytes)) != -1){
                for (int i = 0;i<len;i++){
                    weight[bytes[i]+128] ++;
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return weight;
    }

    /**
     * 压缩文件到指定 dest 路径
     */
    public void encode(){
        HashMap<Integer,String> map = huffTree.codeMap;
        byte index = 0;   //记录在buffer中写入的位数
        byte buffer = 0;    //用于保存8个bit
        //以字节方式读取文件  获取每一个Bit
        /**
         * in : 待压缩文件的读入流
         * out：输出到指定文件的输出流，在文件末尾追加
         * objOut：对象输出流，覆盖文件方式写入
         * 最后流会自动关闭，不需要手动close
         */
        try(BufferedInputStream in  = new BufferedInputStream(new FileInputStream(source));
            BufferedOutputStream out  = new BufferedOutputStream(new FileOutputStream(dest,true));
            ObjectOutputStream objOut = new ObjectOutputStream(new FileOutputStream(config))){
            String huffmanCode;
            byte[] bytes = new byte[1024];
            int len;
            while ((len =in.read(bytes)) != -1){
                for (int i = 0;i<len;i++){
                    huffmanCode = map.get(bytes[i] + 128);
                    for (int j = 0; j < huffmanCode.length(); j++){
                        char c = huffmanCode.charAt(j);
                        if (c == '1'){
                            buffer = setBit(buffer,index);   //将对应位置为1
                        }
                        ++index;
                        //如果buffer已满，则写入文件并重置buffer和index
                        if (index == 8){
                            out.write(buffer);
                            buffer = 0;
                            index = 0;
                        }
                    }
                    down++;
                }
            }

            //如果最后一个字节不满8位，会补全写入，要保存最后一字节的位数
            if (index!=0){
                out.write(buffer);
                fileMsg.lastByteLength = index;
            }


            if (!this.config.exists()) {
                this.config.createNewFile();
            }
            objOut.writeObject(fileMsg);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * 获取文件后缀的方法
     *
     * @param file 要获取文件后缀的文件
     * @return 文件后缀
     */
    public String getFileExtension(File file) {
        String extension = "";
        try {
            if (file != null && file.exists()) {
                String name = file.getName();
                extension = name.substring(name.lastIndexOf("."));
            }
        } catch (Exception e) {
            extension = "";
        }
        return extension;
    }

    private byte setBit(byte b,int index){
        return b |= (1 << ((index) ^ 7));
    }

    public void setDest(File dest) {
        this.dest = dest;
    }

    public int getSchedule(){
        return (int) ((down.doubleValue()/size)*100);
    }
}
