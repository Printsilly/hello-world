package GUI;

import HuffmanUtils.DecodeUtil;
import HuffmanUtils.EncodeUtil;

import java.awt.*;
import java.io.*;
import javax.swing.*;
import javax.swing.filechooser.FileFilter;


public class GUI extends JFrame {

    private static String str = "";     //根据用户选择设置文本框为"压缩文件"或"解压文件"
    private static JFrame frame;        //一级窗口, 菜单选项
    private static String fileName;
    private static EncodeUtil encodeUtil;          //压缩工具类
    private static DecodeUtil decodeUtil;          //解压工具类

    /**
     * 进度条相关
     */
    private static int MIN_PROGRESS = 0;             //最小进度
    private static int MAX_PROGRESS = 100;           //最大进度
    private static int currentProgress = MIN_PROGRESS;     //当前进度


    /**
     * 主函数入口
     * @param args 参数
     */
    public static void main(String[] args) {
        menu();
    }

    /**
     * GUI图形用户界面的初始化
     */
    public void InitUI()
    {
        this.setTitle("压缩");       //设置标题
        this.setBounds(400, 100, 700, 600);         //设置窗体大小和位置
        this.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);   //默认关闭选项
        this.setResizable(false);   //窗体大小不可更改
        this.setLayout(null);       //关闭流式布局

        //添加图标
        ImageIcon icon = new ImageIcon("icon.png");
        this.setIconImage(icon.getImage());

        //添加按钮1 "打开文件"
        JButton button1 = new JButton("打开文件");
        button1.setBounds(170,506, 100, 50);   //设置按钮大小和位置
        button1.setContentAreaFilled(false);  //消除按钮背景颜色
        button1.setOpaque(false);             //除去边框
        button1.setFocusPainted(false);       //出去突起
        button1.setOpaque(true);              //添加背景颜色
        button1.setBackground(new Color(27, 209, 188));  //背景颜色
        button1.setForeground(Color.white);                      //前景颜色
        button1.setFont(new Font("宋体", Font.BOLD, 16));    //设置文本字体
        this.add(button1);

        //添加按钮2 "保存文件"
        JButton button2 = new JButton();
        if (str.equals("压缩文件"))
            button2.setText("开始压缩");       //设置按钮显示
        else
            button2.setText("开始解压");       //设置按钮显示
        button2.setBounds(420,506, 100, 50);    //设置按钮大小和位置
        button2.setContentAreaFilled(false);  //消除按钮背景颜色
        button2.setOpaque(false);             //除去边框
        button2.setFocusPainted(false);       //出去突起
        button2.setOpaque(true);              //设置背景颜色
        button2.setBackground(new Color(27, 209, 188));  //背景颜色
        button2.setForeground(Color.white);                      //前景颜色
        button2.setFont(new Font("宋体", Font.BOLD, 16));    //设置文本字体
        this.add(button2);

        //返回按钮
        //ImageIcon icon2 = new ImageIcon("back.jpg");        //按钮设置成图片
        JButton back = new JButton("返回"); //新建返回按钮
        back.setContentAreaFilled(false);  //消除按钮背景颜色
        back.setOpaque(false);             //除去边框
        back.setFocusPainted(false);       //出去突起
        back.setBounds(0, 0, 70, 30);   //设置按钮大小和位置
        back.setOpaque(true);              //设置背景颜色
        back.setBackground(new Color(70, 140, 194));  //背景颜色
        back.setForeground(Color.white);   //前景颜色
        back.setFont(new Font("宋体", Font.BOLD, 16));    //设置文本字体
        this.add(back);                    //frame界面加入返回按钮
        //事件监听,按下按钮,返回菜单界面
        back.addActionListener(e -> {
            this.setVisible(false);  //二级窗体不可见
            frame.setVisible(true);  //一级窗口可见
        });

        //添加"源文件"文本域
        JTextArea source = new JTextArea();
        source.setEditable(false);              //设置文本不可修改
        source.setText("源文件");               //设置文本名称
        source.setBounds(310, 25, 63, 25);          //设置文本大小和位置
        source.setFont(new Font("宋体", Font.BOLD, 20));    //设置文本字体
        source.setBackground(new Color(204, 204, 204));        //设置文本颜色
        this.add(source);

        //添加"压缩文件"文本域
        JTextArea output = new JTextArea();
        output.setEditable(false);          //设置文本不可修改
        output.setText(str);          //设置文本名称
        output.setBounds(300, 275, 84, 25);         //设置文本大小和位置
        output.setFont(new Font("宋体", Font.BOLD, 20));    //设置文本字体
        output.setBackground(new Color(204, 204, 204));        //设置文本颜色
        this.add(output);

        //设置文本域1, 该文本域位于上方
        JTextArea messArea1 = new JTextArea();
        messArea1.setEditable(false);         //文本域不可修改
        messArea1.setLineWrap(true);          //文本域自动换行
        messArea1.setBounds(0, 50, 700, 200);    //设置文本域大小和位置
        messArea1.setFont(new Font("宋体", Font.BOLD, 20));   //设置字体样式
        this.add(messArea1);

        //设置文本域2, 该文本域位于messArea1下方
        JTextArea messArea2 = new JTextArea();
        messArea2.setEditable(false);         //文本域不可修改
        messArea2.setLineWrap(true);          //文本域自动换行
        messArea2.setBounds(0, 300, 700, 200);  //设置文本域大小和位置
        messArea2.setFont(new Font("宋体", Font.BOLD, 20));   //设置字体样式
        this.add(messArea2);

        //文本域添加滚动条 垂直滚动条显示,水平滚动条不显示
        JScrollPane scroll1 = new JScrollPane(messArea1,
                ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS,
                ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        JScrollPane scroll2 = new JScrollPane(messArea2,
                ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS,
                ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        //设置滚动条矩形参数
        scroll1.setBounds(0, 50, 686, 200);
        scroll2.setBounds(0, 300, 686, 200);
        //滚动条添加到显示框中
        Container c1 = this.getContentPane();
        c1.setBounds(0, 50, 700, 200);
        c1.add(scroll1);
        c1.setBounds(0, 300, 700, 200);
        c1.add(scroll2);

        //为 "打开文件" 和 "保存文件" 按钮添加事件监听
        Listener open = new Listener(this, messArea1);
        button1.addActionListener(open);
        Listener save = new Listener(this, messArea2);
        button2.addActionListener(save);

        this.setVisible(true);      //设置窗体可见
    }

    /**
     * 打开文件
     * @param parent 父线程
     * @param msgTextArea 文本域
     */
    public void showFileOpenDialog(Component parent, JTextArea msgTextArea)
    {
        //创建默认的文件选取器
        JFileChooser fc = new JFileChooser();
        fc.setCurrentDirectory(new File("."));   //设置默认显示为当前文件夹
        fc.setFileSelectionMode(JFileChooser.FILES_AND_DIRECTORIES);  //设置选择模式(文件和文件均可选)
        fc.setMultiSelectionEnabled(false);  //不允许多选

        //文件过滤器
        if (str.equals("解压文件")) {
            //设置文件过滤器
            //实现抽象类FileFilter, 重写内部方法
            fc.setFileFilter(new FileFilter() {
                @Override
                public boolean accept(File f) {
                    return f.getName().endsWith("G02");     //仅选择以G02结尾的文件
                }

                @Override
                public String getDescription() {
                    return ".G02";                          //提示用户选择以G02结尾的文件
                }
            });
        }

        // 打开文件选择框(线程将被阻塞, 直到选择框被关闭)
        int result = fc.showOpenDialog(parent);
        File file1 = fc.getSelectedFile();               //获取文件绝对路径
        fileName = fc.getName(file1).split("\\.")[0];

        String source = file1.getAbsolutePath();

        if (str.equals("解压文件")){
            decodeUtil = new DecodeUtil(source,source);
        }else {
            encodeUtil = new EncodeUtil(source,source);
        }



        if(result == JFileChooser.APPROVE_OPTION)
        {
            File file = fc.getSelectedFile();   //获取打开的文件

            //获取文本文件内容并打印到文本域

            try(BufferedInputStream bis = new BufferedInputStream(new FileInputStream(file))) {
                int tempChar;   //获取文本信息, 每次读取一个字符
                //循环读取文本文件直到读取完毕
                while ((tempChar = bis.read()) != -1) {
                    //读取的文本文件添加到文本域中
                    msgTextArea.append((char) tempChar + "");
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    /**
     * 保存文件
     * @param parent 父线程
     * @param msgTextArea 文本域
     */
    public void showFileSaveDialog(Component parent, JTextArea msgTextArea) {
        // 创建一个默认的文件选取器
        JFileChooser fileChooser = new JFileChooser();

        if (str.equals("解压文件")){
            String fileFormat = decodeUtil.getFileMsg().fileFormat;
            // 设置打开文件选择框后默认输入的文件名
            fileChooser.setSelectedFile(new File(fileName+fileFormat));
        }else{
            fileChooser.setSelectedFile(new File(fileName+".G02"));
        }

        // 打开文件选择框(线程将被阻塞, 直到选择框被关闭)
        int result = fileChooser.showSaveDialog(parent);

        if (result == JFileChooser.APPROVE_OPTION) {
            // 如果点击了"保存", 则获取选择的保存路径
            msgTextArea.setText("");
            File file = fileChooser.getSelectedFile();
            if (str.equals("解压文件")){
                progressBar();
                decodeUtil.setDest(file.getAbsolutePath());
                decodeUtil.decode();
                try(BufferedInputStream bis = new BufferedInputStream(new FileInputStream(file))) {
                    int tempChar;   //获取文本信息, 每次读取一个字符
                    //循环读取文本文件直到读取完毕
                    while ((tempChar = bis.read()) != -1) {
                        //读取的文本文件添加到文本域中
                        msgTextArea.append((char) tempChar + "");
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }else {
                progressBar();
                encodeUtil.setDest(file);
                encodeUtil.encode();
                try(BufferedInputStream bis = new BufferedInputStream(new FileInputStream(file))) {
                    int tempChar;   //获取文本信息, 每次读取一个字符
                    //循环读取文本文件直到读取完毕
                    while ((tempChar = bis.read()) != -1) {
                        //读取的文本文件添加到文本域中
                        msgTextArea.append((char) tempChar + "");
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }
    }

    /**
     * 一级菜单, 用户选择执行的操作, 跳转到二级菜单
     */
    public static void menu()
    {
        //一级窗体
        frame = new JFrame("G02专属压缩工具");

        //添加图标
        ImageIcon icon = new ImageIcon("icon.png");
        frame.setIconImage(icon.getImage());

        JLayeredPane layeredPane=new JLayeredPane();    //图层
        ImageIcon image = new ImageIcon("background.jpg");      //添加背景图片
        JPanel panel = new JPanel();                    //图层
        panel.setBounds(0,0,image.getIconWidth(),image.getIconHeight());
        JLabel label = new JLabel(image);               //添加背景图片
        panel.add(label);                               //添加背景图片

        //窗口跳转
        JButton b1 = new JButton("压缩文件");           //用户选择压缩文件
        b1.setBounds(50,100,170,70);
        b1.setContentAreaFilled(false);  //消除按钮背景颜色
        b1.setOpaque(false);             //除去边框
        b1.setFocusPainted(false);       //出去突起
        b1.setFont(new Font("宋体", Font.BOLD, 30));
        b1.setOpaque(true);              //背景为透明
        b1.setBackground(new Color(27, 209, 188));  //背景颜色
        b1.setForeground(Color.white);   //前景颜色
        frame.add(b1);                   //按钮加入frame
        //事件监听,按下按钮,窗口实现跳转
        b1.addActionListener(e -> {
            //frame.dispose();          //销毁一级窗体
            frame.setVisible(false);
            str = "压缩文件";
            GUI gui = new GUI();      //新窗口
            gui.InitUI();             //初始化GUI
        });

        JButton b2 = new JButton("解压文件");           //用户选择解压文件
        b2.setBounds(270,100,170,70);
        b2.setContentAreaFilled(false);  //消除按钮背景颜色
        b2.setOpaque(false);             //除去边框
        b2.setFocusPainted(false);       //出去突起
        b2.setFont(new Font("宋体", Font.BOLD, 30));
        b2.setOpaque(true);              //设置背景为透明
        b2.setBackground(new Color(27, 209, 188));  //背景颜色
        b2.setForeground(Color.white);   //前景颜色
        frame.add(b2);                   //加入一级窗体
        //事件监听,按下按钮,窗口实现跳转
        b2.addActionListener(e -> {
            //frame.dispose();          //销毁一级窗体
            frame.setVisible(false);  //一级窗体不可见
            str = "解压文件";
            GUI gui = new GUI();      //新窗口
            gui.InitUI();             //初始化GUI
        });

        //将panel放到最底层
        layeredPane.add(panel,JLayeredPane.DEFAULT_LAYER);
        //将button放到高一层的地方
        layeredPane.add(b1,JLayeredPane.MODAL_LAYER);
        layeredPane.add(b2,JLayeredPane.MODAL_LAYER);

        frame.setLayeredPane(layeredPane);      //设置图层
        frame.setBounds(0, 0, 500, 300);        //窗体大小
        frame.setResizable(false);   //一级窗体大小不可更改
        frame.setLayout(null);       //关闭流式布局
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);   //默认关闭方式
        frame.setLocation(image.getIconWidth(),image.getIconHeight());
        frame.setVisible(true);      //一级窗体可见
        frame.setLocationRelativeTo(null);
    }

    /**
     * 进度条
     */
    private static void progressBar() {

        //重置进度
        MIN_PROGRESS = 0;                   //最小进度
        MAX_PROGRESS = 100;                 //最大进度
        currentProgress = MIN_PROGRESS;     //当前进度

        //创建3级窗体
        JFrame frame3 = new JFrame("进度");
        frame3.setSize(500, 100);    //窗体大小
        frame3.setResizable(false);                //窗体大小不可更改
        frame3.setLocationRelativeTo(null);        //进度条显示在中央
        frame3.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);      //默认关闭方式

        //添加图标
        ImageIcon icon = new ImageIcon("icon.png");
        frame3.setIconImage(icon.getImage());

        JPanel panel = new JPanel();    //面板组件
        panel.setLayout(null);          //关闭面板布局

        //创建一个进度条
        final JProgressBar progressBar = new JProgressBar();
        //设置进度条位置
        progressBar.setBounds(40,20,400,30);

        //设置进度的最小值 和 最大值
        progressBar.setMinimum(MIN_PROGRESS);
        progressBar.setMaximum(MAX_PROGRESS);
        //设置当前进度值
        progressBar.setValue(currentProgress);

        // 绘制百分比文本(进度条中间显示的百分数)
        progressBar.setStringPainted(true);

        // 添加到内容面板
        panel.add(progressBar);
        frame3.setContentPane(panel);
        frame3.setVisible(true);

        //延时操作进度, 每隔 100 ms 更新进度
        new Timer(100, e -> {
            //进度条进度设置
//            if (str.equals("解压文件")){
//                currentProgress = decodeUtil.getSchedule();
//            }else {
//                currentProgress = encodeUtil.getSchedule();
//            }
            currentProgress = currentProgress + 7;
            if (currentProgress >= MAX_PROGRESS) {
                frame3.setVisible(false);
            }
            progressBar.setValue(currentProgress);
        }).start();
    }
}


