package GUI;

import java.awt.event.*;
import javax.swing.JTextArea;

/**
 * 事件监听类, 负责为打开文件和保存文件添加事件监听
 */
public class Listener implements ActionListener{
    private GUI gui;                  //GUI类的实例
    private JTextArea msgTextArea;    //文本域

    /**
     * 构造器, 负责实例化Test类和文本域
     * @param gui GUI类实例
     * @param msgTextArea 文本域
     */
    public Listener(GUI gui, JTextArea msgTextArea) {
        super();
        this.gui = gui;                     //实例化GUI类
        this.msgTextArea = msgTextArea;     //实例化文本域
    }

    /**
     * 为打开文件和保存文件添加事件监听
     * @param e 事件监听器
     */
    public void actionPerformed(ActionEvent e) {

        //打开文件事件监听
        if(e.getActionCommand().equals("打开文件"))
        {
            //调用打开文件函数
            gui.showFileOpenDialog(gui, msgTextArea);
        }

        //保存文件事件监听
        else if(e.getActionCommand().equals("开始压缩") || e.getActionCommand().equals("开始解压"))
        {
            //调用保存文件函数
            gui.showFileSaveDialog(gui, msgTextArea);
        }
    }
}
