package HuffmanTree;

public class InterNode extends HuffNode {
    //左孩子
    public HuffNode left;
    //右孩子
    public HuffNode right;


    public InterNode(HuffNode left, HuffNode right, int weight){
        super(weight);
        this.left = left;
        this.right = right;
    }

    @Override
    public boolean isLeaf() {
        return false;
    }

    @Override
    public int getValue() {
        return 0;
    }

    @Override
    public HuffNode getLeft() {
        return left;
    }

    @Override
    public HuffNode getRight() {
        return right;
    }

}
