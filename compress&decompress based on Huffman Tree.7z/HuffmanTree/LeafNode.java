package HuffmanTree;

public class LeafNode extends HuffNode {
    //value保存当前是哪个字符（0~255）
    private int value;

    public LeafNode(int value,int weight){
        super(weight);
        this.value = value;
    }

    @Override
    public boolean isLeaf() {
        return true;
    }

    @Override
    public int getValue() {
        return value;
    }

    @Override
    public HuffNode getLeft() {
        return null;
    }

    @Override
    public HuffNode getRight() {
        return null;
    }
}
