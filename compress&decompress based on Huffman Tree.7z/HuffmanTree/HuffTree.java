package HuffmanTree;

import HuffmanTree.HuffNode;
import HuffmanTree.InterNode;
import HuffmanTree.LeafNode;

import java.util.*;

public class HuffTree {

    private HuffNode root;
    //用于保存初始的带权叶子结点
    public ArrayList<HuffNode> initTree;
    //用于保存最后各个字符对应的哈夫曼编码
    public HashMap<Integer,String> codeMap;

    //返回根节点
    public HuffNode getRoot() {
        return root;
    }

    //返回根结点权值
    public int getWeight(){
        return root.getWeight();
    }

    //将数组中的带权值的值提出来 用于后续建立哈夫曼树
    public void setArrayList(int[] array) {

        //遍历256个数 找到权值不为0的放到 initTree 里面去
        for(int i = 0;i < array.length;i++){
            if(array[i] > 0){
                initTree.add(new LeafNode(i,array[i]));
            }
        }
    }

    //插入排序 将initTree按权值 升序 排好
    public void mySort()
    {
        for (int i = 1; i < initTree.size(); i++)
        {
            HuffNode temp = initTree.get(i);//当前要排的结点
            int cur = temp.getWeight();     //当前要排的的结点的权值
            int j;
            for (j = i - 1; j >= 0 && cur <= initTree.get(j).getWeight(); j--)
            {
                initTree.set(j+1,initTree.get(j));
            }
            initTree.set(j+1,temp);
        }
    }

    //建立哈夫曼树 在这个构造函数中 root codeMap 都会被初始化 initTree只剩下root结点
    public  HuffTree(int[] array){

        initTree = new ArrayList();
        codeMap = new HashMap();

        //读传入的数组构造最初的initTree
        setArrayList(array);

        //排到 initTree中只剩一个元素说明 建树完成
        while(initTree.size()>1){
            //对 initTree重新进行排序
            mySort();
            //从initTree 中拿到权值最小的两个结点
            HuffNode temp1 = initTree.get(0);
            HuffNode temp2 = initTree.get(1);
            //建立一个新的中间结点 其权值为左右子结点之和
            HuffNode temp = new InterNode(temp1, temp2, temp1.getWeight() + temp2.getWeight());
            //将之前的两个权值最小的结点从 initTree中移除
            initTree.remove(0);
            initTree.remove(0);
            //将新建立的中间结点加入initTree
            initTree.add(temp);
        }

        //建树完成
        if(initTree.get(0).isLeaf())
            root = new InterNode(initTree.get(0),null,initTree.get(0).getWeight());
        else
            root = initTree.get(0);
        //初始化哈夫曼编码
        huffCode(root,"");
    }

    //得到各个字符的哈夫曼编码，保存在codeMap中
    public void huffCode(HuffNode p,String temp){
        if(!p.isLeaf()){

            if(p.getLeft() != null){
                huffCode(p.getLeft(),temp +"0");
            }
            if(p.getRight() != null){
                huffCode(p.getRight(),temp +"1");
            }
        }
        else
            codeMap.put(p.getValue(),temp);
    }
}