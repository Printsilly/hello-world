package HuffmanTree;

public abstract class HuffNode {
    private int weight;

    //判断当前结点是不是叶结点 LeafNode返回True InterNode返回False
    public abstract boolean isLeaf();

    //返回当前的字符（0~255） 只有叶结点有效 内部结点默认返回0
    public abstract int getValue();

    //返回左孩子 叶结点返回null
    public abstract HuffNode getLeft();

    //返回右孩子 叶结点返回null
    public abstract HuffNode getRight();

    //返回当前结点权值
    public int getWeight() {
        return weight;
    }

    public HuffNode(int weight){
        this.weight = weight;
    }
}
